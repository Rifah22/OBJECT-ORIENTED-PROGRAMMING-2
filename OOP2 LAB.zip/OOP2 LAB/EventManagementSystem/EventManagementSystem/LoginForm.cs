﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EventManagementSystem
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text;
            string password = txtPassword.Text;

            string query = "select * from UserInfo where Email='"+email+"' and [Password]='"+password+"' ";

            string error;
            DataTable dt = DataAccess.GetData(query,out error);
            
            if(string.IsNullOrEmpty(error) == false)
            {
                MessageBox.Show(error,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }

            if(dt.Rows.Count ==0)
            {
                MessageBox.Show("Invalid Email or Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string userType = dt.Rows[0]["UserType"].ToString();
            
            if(userType =="Admin")
            {
                AdminForm af = new AdminForm();
                af.Show();
                this.Hide();
            }
            else if (userType == "Employee")
            {
                EmployeeForm ef = new EmployeeForm();
                ef.Show();
                this.Hide();
            }
            else if (userType == "Customer")
            {
                CustomerForm ef = new CustomerForm();
                ef.Show();
                this.Hide();
            }

        }
    }
}
