﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EventManagementSystem
{
    public partial class ManageEventTypes : MetroFramework.Forms.MetroForm
    {
        public ManageEventTypes()
        {
            InitializeComponent();
        }

        private void ManageEventTypes_Load(object sender, EventArgs e)
        {
            this.LoadEventTypes();
        }

        private void LoadEventTypes()
        {
            string query = "select Id,Title from EventType";
            string error;

            DataTable dt = DataAccess.GetData(query, out error);

            if (string.IsNullOrEmpty(error) == false)
            {
                MessageBox.Show(error, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            dgvEventType.AutoGenerateColumns = false;
            dgvEventType.DataSource = dt;
            dgvEventType.Refresh();
            dgvEventType.ClearSelection();

        }


        private void button1_Click(object sender, EventArgs e)
        {
            AdminForm af = new AdminForm();
            af.Show();
            this.Hide();
        }

        private void ManageEventTypes_FormClosing(object sender, FormClosingEventArgs e)
        {
            AdminForm af = new AdminForm();
            af.Show();
        }

        private void metroButton3_Click(object sender, EventArgs e)
        {
            this.LoadEventTypes();
        }
    }
}
