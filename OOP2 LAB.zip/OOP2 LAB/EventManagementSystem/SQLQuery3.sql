﻿insert into EventType (Title) output inserted.Id values ('Mehedi')
