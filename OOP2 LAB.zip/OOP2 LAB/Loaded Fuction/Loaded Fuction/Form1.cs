﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml.Linq;

namespace Loaded_Fuction
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Password_Changed(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtPassword.Text) || string.IsNullOrEmpty(txtCPassword.Text))
            {
                lblerror.Visible = false;

            }
            else if (txtPassword.Text != txtCPassword.Text)
            {
                lblerror.Visible = true;
            }
            else
            {
                lblerror.Visible = false;
            }

        }
        private void button1_Click1(object sender, EventArgs e)
        {
            string un = textBox1.Text;
            string pass = txtPassword.Text;
            DateTime dob = Convert.ToDateTime(dtpDOB.Text);

            if (cmbDepartment.SelectedItem == null)
            {
                MessageBox.Show(text: "Invalid Department");
                return;
            }
            string department = cmbDepartment.SelectedItem.ToString();

            string gender = "";

            if (rbtnMale.Checked == true)
                gender = "Male";
            else if (rbtnFemale.Checked == true)
                gender = "Female";
            else
            {
                MessageBox.Show(text: "Invalid Gender");
                return;
            }


            string employeeType = "";

            if (rbtnFT.Checked == true)
                employeeType = "FullTime";
            else if (rbtnPT.Checked == true)
                employeeType = "PartTime";
            else
            {
                MessageBox.Show(text: "Invalid Employee Type");
                return;
            }
            string address = rtxAddress.Text;
            string skills = "";

            if (chkC.Checked == true)
                skills += "C#";
            if (chkJava.Checked == true)
                skills += "Java";
            if (chkPython.Checked == true)
                skills += "Python";


            //MessageBox.Show(text: un + "\n" + pass + "\n" + dob.ToString(format: "dd-mmm-yyyy")
            //   +"\n"+ department + "\n" + gender + "\n" + EmployeeType + "\n" + skills + "\n" +
            //   address);

            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\rifah\Documents\6th Semester\OOP2 LAB\EventManagementSystem\Loaded function.mdf"";Integrated Security=True;Connect Timeout=30");
                con.Open();

                string query = "insert into Registration(UserName,[Password]) values ('" + un + "','" + pass + "')";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show(text: "Operation Completed");
                con.Close();
            }

            catch (Exception exception)

            {
                MessageBox.Show(text: "Something Went Wrong.");
                
            }
        }

        private void button2_Click1(object sender, EventArgs e)
        {
            try
            {

                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\rifah\Documents\6th Semester\OOP2 LAB\EventManagementSystem\Loaded function.mdf"";Integrated Security=True;Connect Timeout=30");
                con.Open();

                string query = "select * from Registration;";
                SqlCommand cmd = new SqlCommand(query, con);

                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adp.Fill(ds);

                DataTable dt = ds.Tables[0];

                dgbRegistration.DataSource = dt;
                dgbRegistration.Refresh();

                con.Close();
            }

            catch (Exception exception)

            {
                MessageBox.Show(text: "Something Went Wrong.");
               // error = exception.Message;
            }

        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {

        }
    }
}
