﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Advanced_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnNumber_Click(object sender, EventArgs e)
        {
            Button btn = (Button) sender;

            if (btn.Text == "." && textno.Text.Contains("."))
            {
                MessageBox.Show(text: "Already dot contained");
                return;
            }
            textno.Text += btn.Text;
        }
        private void button9_Click(object sender, EventArgs e)
        {
            ldlfn.Text = textno.Text;
            ldlopt.Text = "+";
            textno.Text = " ";
        }
        private void button8_Click(object sender, EventArgs e)
        {
            ldlfn.Text = textno.Text;
            ldlopt.Text = "-";
            textno.Text = " ";
        }
        private void button7_Click(object sender, EventArgs e)
        {
            ldlfn.Text = textno.Text;
            ldlopt.Text = "*";
            textno.Text = " ";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            ldlfn.Text = textno.Text;
            ldlopt.Text = "/";
            textno.Text = " ";
        }
        private void button5_Click(object sender, EventArgs e)
        {
            ldlfn.Text = textno.Text;
            ldlopt.Text = "=";
            textno.Text = " ";
        }
        private void txtNo(object sender, EventArgs e)
        {

        }

        private void textno_TextChanged(object sender, EventArgs e)
        {

        }

    }
}
