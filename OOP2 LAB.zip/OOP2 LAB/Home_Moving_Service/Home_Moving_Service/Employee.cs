﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Home_Moving_Service
{


    class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }

        public Employee()
        {

            Console.WriteLine("Parent E Constructor");
        }



        public Employee(int id, string name, string address)
        {

            this.Id = id;
            this.Name = name;
            this.Address = address;
            Console.WriteLine("Parent P Constructor");
        }



        public void ShowInfo()
        {
            Console.WriteLine("Employee ID:" + this.Id);
            Console.WriteLine("Name:" + this.Name);
            Console.WriteLine("Address:" + this.Address);
        }



        public virtual void EmployeeStatus()
        {
            Console.WriteLine("Employee is not eligible for a bonus.");
        }


    }