﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Home_Moving_Service
{
    
        class Laborer : Employee

        {

            public double UserRating { get; set; }

            public int ChargePerService { get; } = 500;

            public int NoOfServices { get; set; }



            public Laborer(int id, string name, string address, double userRating, int noOfServices)

                : base(id, name, address)

            {

                UserRating = userRating;

                NoOfServices = noOfServices;

            }



            public override void EmployeeStatus()

            {

                if (UserRating > 70 && NoOfServices >= 10)

                    Console.WriteLine("Laborer is eligible for a bonus.");

                else

                    Console.WriteLine("Laborer is not eligible for a bonus.");

            }



            public double TotalEarn()

            {

                return ChargePerService * NoOfServices;

            }



            public void ShowInfo()

            {

                base.ShowInfo();

                Console.WriteLine("User Rating: {UserRating}%");

                Console.WriteLine("Number of Services: {NoOfServices}");

                EmployeeStatus();

                Console.WriteLine("Total Earnings: {TotalEarn()} BDT");

            }

        }
    }
    
