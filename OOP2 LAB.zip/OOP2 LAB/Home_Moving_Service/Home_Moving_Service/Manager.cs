﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Home_Moving_Service
{
     
    
        class Manager : Employee

        {

            public int YearsOfExperience { get; set; }



            public Manager(int id, string name, string address, int yearsOfExperience)

                : base(id, name, address)

            {

                this.YearsOfExperience = yearsOfExperience;

            }



            public override void EmployeeStatus()

            {

                if (YearsOfExperience > 2)

                    Console.WriteLine("Manager is eligible for a bonus.");

                else

                    Console.WriteLine("Manager is not eligible for a bonus.");

            }



            public void ShowInfo()

            {

                base.ShowInfo();

                Console.WriteLine("Years of Experience: {YearsOfExperience} years");

                EmployeeStatus();

            }

        }

    
}

    

