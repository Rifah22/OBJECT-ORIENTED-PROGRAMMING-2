﻿using Home_Moving_Service;

class Program
{
    static void Main(string[] args)
    {
        Employee employee = new Employee();
        Laborer laborer = new Laborer(1, "Rifah", "78 Motijheel", 60, 25);
        Manager manager = new Manager(2, "Sanzida", "50 kamalapur", 5);
        Console.WriteLine("Employee Information:");
        employee.ShowInfo();
        Console.WriteLine("\nLaborer Information:");
        laborer.ShowInfo();
         Console.WriteLine("\nManager Information:");
        manager.ShowInfo();
    }
}