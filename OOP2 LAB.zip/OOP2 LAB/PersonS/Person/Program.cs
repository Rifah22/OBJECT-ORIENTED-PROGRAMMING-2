﻿using System;


class Person
{
    public string Name { get; set; }
    public string Address { get; set; }
    public string PhoneNumber { get; set; }

    public Person(string name, string address, string phoneNumber)
    {
        Name = name;
        Address = address;
        PhoneNumber = phoneNumber;
    }

    
}

class Customer : Person
{
    public bool MailingList { get; set; }
    public double TotalSpending { get; set; }

    public Customer(string name, string address, string phoneNumber, bool mailingList)
        : base(name, address, phoneNumber)
    {
        MailingList = mailingList;
        TotalSpending = 0.0;
    }

    public void AddPurchase(double amount)
    {
        TotalSpending += amount;
    }

    public double CalculateDiscount()
    {
        if (TotalSpending >= 2000)
        {
            return TotalSpending * 0.05;
        }
        else if (TotalSpending >= 1000)
        {
            return TotalSpending * 0.025;
        }
        else if (TotalSpending >= 500)
        {
            return TotalSpending * 0.02;
        }
        else
        {
            return 0.0;
        }
    }
}

class Program
{
    static void Main()
    {
        Customer customer = new Customer("Yeasin", " Dhaka", "0134322 ", true);
        customer.AddPurchase(800);
        double discount = customer.CalculateDiscount();
        Console.WriteLine($"Customer Name: {customer.Name}");
        Console.WriteLine($"Total Spending: TK. {customer.TotalSpending}");
        Console.WriteLine($"Discount: TK. {discount}");
    }
}
