﻿CREATE TABLE [dbo].[EventBooking]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [EventTypeID] INT NOT NULL, 
    [ConventionPlaceID] INT NOT NULL, 
    [FoodPackageID] INT NOT NULL, 
    [CustomerID] INT NOT NULL, 
    [Date] DATETIME NOT NULL, 
    [Guest] INT NOT NULL, 
    [TotalBill(Auto Calculated)] DECIMAL NOT NULL
)
