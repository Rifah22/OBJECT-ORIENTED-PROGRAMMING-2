﻿CREATE TABLE [dbo].[Employee]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Salary] INT NOT NULL, 
    [JoiningDate] DATETIME NOT NULL, 
    CONSTRAINT [FK_Employee_Id] FOREIGN KEY ([Id]) REFERENCES Id(Id) 
)
