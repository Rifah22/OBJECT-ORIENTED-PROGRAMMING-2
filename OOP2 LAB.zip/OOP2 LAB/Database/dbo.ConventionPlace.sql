﻿CREATE TABLE [dbo].[ConventionPlace] (
    [Id]      INT            IDENTITY (1, 1) NOT NULL,
    [Title]   NVARCHAR (150) NOT NULL,
    [Address] NVARCHAR (500) NOT NULL,
    [Guest]   INT            NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

