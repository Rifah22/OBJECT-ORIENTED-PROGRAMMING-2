﻿CREATE TABLE [dbo].[EventPayment]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [EventBookingID] INT NOT NULL, 
    [Date] DATETIME NOT NULL, 
    [Amount] DECIMAL NOT NULL
)
