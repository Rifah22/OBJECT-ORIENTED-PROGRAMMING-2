﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ITCompany
{
    class JoinDate
    {
        public int Day { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
        public JoinDate (int day,int month,int year)
        {
            this.Day = day;
            this.Month = month;
            this.Year = year;
        }
        public override string ToString()
        {
            return $"{Day}/{Month}/{Year}";
         }



    }
}
