﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ITCompany
{
    abstract class Employee
    {
     public string Id { get; set; }
     public string Name { get; set; }
     public double Salary { get; set; }
     public JoinDate JoinDate { get; set; }
     public Employee(string id,string name,double salary,JoinDate joindate)
      {
            this.Id = id;
            this.Name = name;
            this.Salary = salary;
            this.JoinDate = joindate;
      }
        public abstract double GrossIncome();
        public void ShowInfo()
        {
            Console.WriteLine("ID:" + Id);
            Console.WriteLine("Name:" + Name);
            Console.WriteLine("Salary:" + Salary);
            Console.WriteLine("JoinDate:" + JoinDate);
        }
    }
    class FullTime:Employee
    {
        public FullTime(string id, string name, double salary, JoinDate joinDate, double bonus) 
            : base(id, name, salary, joinDate)
        {
            this.Bonus = bonus;
        }

        public double Bonus { get; set; }

        public override double GrossIncome()
        {
            double totalSalary = 12 * Salary;
            double totalBonus = 2 * Bonus;
            return totalSalary + totalBonus;
        }
    }

    class PartTime : Employee
    {
        public PartTime(string id, string name, double salary, JoinDate joinDate, double commission)
            : base(id, name, salary, joinDate)
        {
            this.Commission = commission;
        }

        public double Commission { get; set; }

        public override double GrossIncome()
        {
            double totalSalary = 12 * Salary;
            return totalSalary + Commission;
        }
    }
}

     


