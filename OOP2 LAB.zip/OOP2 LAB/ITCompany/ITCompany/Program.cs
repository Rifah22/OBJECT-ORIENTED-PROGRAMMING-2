﻿using ITCompany;
using System;

namespace ConsoleAppEmployeeInformation
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee[] emp = new Employee[2];
            emp[0] = new FullTime("E-001", "Saef", 30000, new JoinDate(12, 09, 2013), 15000);
            emp[1] = new PartTime("E-002", "Kawsur", 12000, new JoinDate(23, 07, 2019), 1300);

            foreach (Employee e in emp)
            {
                e.ShowInfo();
                e.GrossIncome();
            }
        }
    }
}


