﻿
namespace E_Commerce_Management_System
{
    partial class Seller_Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Seller_Dashboard));
            this.bS_R_F = new System.Windows.Forms.Button();
            this.b_P_L = new System.Windows.Forms.Button();
            this.b_S_V = new System.Windows.Forms.Button();
            this.l_S_D = new System.Windows.Forms.Label();
            this.blogout = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bS_R_F
            // 
            this.bS_R_F.BackColor = System.Drawing.Color.Silver;
            this.bS_R_F.Font = new System.Drawing.Font("Matura MT Script Capitals", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bS_R_F.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.bS_R_F.Location = new System.Drawing.Point(59, 197);
            this.bS_R_F.Name = "bS_R_F";
            this.bS_R_F.Size = new System.Drawing.Size(192, 78);
            this.bS_R_F.TabIndex = 0;
            this.bS_R_F.Text = " Registration Form";
            this.bS_R_F.UseVisualStyleBackColor = false;
            this.bS_R_F.Click += new System.EventHandler(this.bS_R_F_Click);
            // 
            // b_P_L
            // 
            this.b_P_L.BackColor = System.Drawing.Color.Silver;
            this.b_P_L.Font = new System.Drawing.Font("Matura MT Script Capitals", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_P_L.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.b_P_L.Location = new System.Drawing.Point(319, 197);
            this.b_P_L.Name = "b_P_L";
            this.b_P_L.Size = new System.Drawing.Size(144, 78);
            this.b_P_L.TabIndex = 1;
            this.b_P_L.Text = "Product List";
            this.b_P_L.UseVisualStyleBackColor = false;
            this.b_P_L.Click += new System.EventHandler(this.b_P_L_Click);
            // 
            // b_S_V
            // 
            this.b_S_V.BackColor = System.Drawing.Color.Silver;
            this.b_S_V.Font = new System.Drawing.Font("Matura MT Script Capitals", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_S_V.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.b_S_V.Location = new System.Drawing.Point(531, 197);
            this.b_S_V.Name = "b_S_V";
            this.b_S_V.Size = new System.Drawing.Size(134, 78);
            this.b_S_V.TabIndex = 2;
            this.b_S_V.Text = "View List";
            this.b_S_V.UseVisualStyleBackColor = false;
            this.b_S_V.Click += new System.EventHandler(this.b_S_V_Click);
            // 
            // l_S_D
            // 
            this.l_S_D.AutoSize = true;
            this.l_S_D.BackColor = System.Drawing.Color.MistyRose;
            this.l_S_D.Font = new System.Drawing.Font("Matura MT Script Capitals", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l_S_D.ForeColor = System.Drawing.Color.Navy;
            this.l_S_D.Location = new System.Drawing.Point(218, 70);
            this.l_S_D.Name = "l_S_D";
            this.l_S_D.Size = new System.Drawing.Size(293, 42);
            this.l_S_D.TabIndex = 0;
            this.l_S_D.Text = "Seller Dashboard";
            this.l_S_D.Click += new System.EventHandler(this.l_S_D_Click);
            // 
            // blogout
            // 
            this.blogout.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("blogout.BackgroundImage")));
            this.blogout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.blogout.Location = new System.Drawing.Point(631, 364);
            this.blogout.Name = "blogout";
            this.blogout.Size = new System.Drawing.Size(94, 51);
            this.blogout.TabIndex = 3;
            this.blogout.UseVisualStyleBackColor = true;
            this.blogout.Click += new System.EventHandler(this.blogout_Click);
            // 
            // Seller_Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(726, 414);
            this.Controls.Add(this.blogout);
            this.Controls.Add(this.l_S_D);
            this.Controls.Add(this.b_S_V);
            this.Controls.Add(this.b_P_L);
            this.Controls.Add(this.bS_R_F);
            this.Name = "Seller_Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Seller_Dashboard";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bS_R_F;
        private System.Windows.Forms.Button b_P_L;
        private System.Windows.Forms.Button b_S_V;
        private System.Windows.Forms.Label l_S_D;
        private System.Windows.Forms.Button blogout;
    }
}