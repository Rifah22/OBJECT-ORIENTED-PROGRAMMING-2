﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace E_Commerce_Management_System
{
    public partial class Seller_Dashboard : Form
    {
        public Seller_Dashboard()
        {
            InitializeComponent();
        }

        private void l_S_D_Click(object sender, EventArgs e)
        {

        }

        private void bS_R_F_Click(object sender, EventArgs e)
        {
            Dashboard sg = new Dashboard();
            sg.Show();
            this.Hide();
        }

        private void b_P_L_Click(object sender, EventArgs e)
        {
            Product p = new Product();
            p.Show();
            this.Hide();
        }

        private void b_S_V_Click(object sender, EventArgs e)
        {
            All_View av = new All_View();
            av.Show();
            this.Hide();
        }

        private void blogout_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
