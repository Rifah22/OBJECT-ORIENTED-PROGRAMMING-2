﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace E_Commerce_Management_System
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }
        private void Password_Changed(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtPas.Text) || string.IsNullOrEmpty(txtCpass.Text))
            {
                lblerror.Visible = false;

            }
            else if (txtPas.Text != txtCpass.Text)
            {
                lblerror.Visible = true;
            }
            else
            {
                lblerror.Visible = false;
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtSN.Text) && string.IsNullOrEmpty(txtPas.Text) && string.IsNullOrEmpty(txtCon.Text) && string.IsNullOrEmpty(txtAdd.Text))
            {
                // string sid = txtId.Text;
                string sname = txtSN.Text;
                string spass = txtPas.Text;
                string scontact = txtCon.Text;
                string saddress = txtAdd.Text;


                //MessageBox.Show(text: sid+ "\n" + sname + "\n" + pass
                // +"\n"+ phone + "\n" + address);
                /* try*/
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\rifah\Downloads\SellerDB\SellerDB\SellerDB.mdf;Integrated Security=True;Connect Timeout=30");
                con.Open();



                String query1 = "insert into Seller_Reg(Seller_name,Seller_address,Seller_pass,Seller_phone_no) values ('" + txtSN.Text + "','" + txtAdd.Text + "','" + txtPas.Text + "','" + txtCon.Text + "')";
                // String query2 = "select Seller_id from Seller_reg where Seller_name = '"+txtSN.Text+"' and[Seller_pass] = '"+txtPas.Text+"'";
                SqlCommand cmd = new SqlCommand(query1, con);
                cmd.ExecuteNonQuery();
                /*SqlDataAdapter sdta = new SqlDataAdapter(query2, con);

                DataTable dt = new DataTable();
                sdta.Fill(dt);
                string UN = "Welcome " + dt.Rows[0]["Seller_Name"].ToString();
                MessageBox.Show(SN, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //uId = Int32.Parse(dt.Rows[0]["Seller_Id"].ToString());

                */

                MessageBox.Show(text: "Operation Completed");
                con.Close();
                Login login = new Login();
                this.Hide();
                login.Show();
            }

            else
            {
                MessageBox.Show("Please fill all the box");
            }
        }

        private void linkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login login = new Login();
            this.Hide();
            login.Show();
        }
    }
}
